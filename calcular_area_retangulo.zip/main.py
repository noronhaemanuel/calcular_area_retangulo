
# Programa para calcular a área de um retângulo

def calcular_area_retangulo(base, altura):
    return base * altura

def main():
    try:
        base = float(input("Digite a base do retângulo: "))
        altura = float(input("Digite a altura do retângulo: "))
        area = calcular_area_retangulo(base, altura)
        print(f"A área do retângulo é: {area}")
    except ValueError:
        print("Por favor, insira valores numéricos válidos.")

if __name__ == "__main__":
    main()
